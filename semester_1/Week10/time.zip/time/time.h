#ifndef TIME_H_INCLUDED
#define TIME_H_INCLUDED

#define PARSE_FORMAT "%d/%m/%Y %H:%M:%S"

int process(const char *input);
#endif // TIME_H_INCLUDED
